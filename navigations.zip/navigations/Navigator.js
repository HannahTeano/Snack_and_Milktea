import React from 'react'
import {createStackNavigator} from '@react-navigation/stack'
import Home from '../screens/Home'
import DetailFries from '../screens/DetailFries'
import DetailCookies from '../screens/DetailCookies'
import DetailPopcorn from '../screens/DetailPopcorn'
import DetailPotato from '../screens/DetailPotato'
import DetailSalad from '../screens/DetailSalad'
import DetailBurrito from '../screens/DetailBurrito'
import Burger from '../screens/Burger'
import Milktea from '../screens/Milktea'
import Pizza from '../screens/Pizza'
import Donut from '../screens/Donut'
import About from '../screens/About'
import Home1 from '../screens/Home1'
import Members from '../screens/Members'
import Lanz from '../screens/Lanz'
import Charmie from '../screens/Charmie'
import Jean from '../screens/Jean'
import Sophia from '../screens/Sophia'
import Hannah from '../screens/Hannah'
import MilkteaDetail1 from '../screens/MilkteaDetail1'
import MilkteaDetail2 from '../screens/MilkteaDetail2'
import MilkteaDetail3 from '../screens/MilkteaDetail3'
import MilkteaDetail4 from '../screens/MilkteaDetail4'
import MilkteaDetail5 from '../screens/MilkteaDetail5'
import MilkteaDetail6 from '../screens/MilkteaDetail6'
import BurgerDetail1 from '../screens/BurgerDetail1'
import BurgerDetail2 from '../screens/BurgerDetail2'
import BurgerDetail3 from '../screens/BurgerDetail3'
import BurgerDetail4 from '../screens/BurgerDetail4'
import BurgerDetail5 from '../screens/BurgerDetail5'
import BurgerDetail6 from '../screens/BurgerDetail6'
import DonutDetail1 from '../screens/DonutDetail1'
import DonutDetail2 from '../screens/DonutDetail2'
import DonutDetail3 from '../screens/DonutDetail3'
import DonutDetail4 from '../screens/DonutDetail4'
import DonutDetail5 from '../screens/DonutDetail5'
import DonutDetail6 from '../screens/DonutDetail6'
import PizzaDetail1 from '../screens/PizzaDetail1'
import PizzaDetail2 from '../screens/PizzaDetail2'
import PizzaDetail3 from '../screens/PizzaDetail3'
import PizzaDetail4 from '../screens/PizzaDetail4'
import PizzaDetail5 from '../screens/PizzaDetail5'
import PizzaDetail6 from '../screens/PizzaDetail6'







const Stack = createStackNavigator();
const screenOptionStyle = {
    headerShown:false
}

const HomeStackNavigator = () => {
    return(
        <Stack.Navigator screenOptions={screenOptionStyle}>
            <Stack.Screen name="Home" component={Home}/>
            <Stack.Screen name="DetailFries" component={DetailFries}/>
            <Stack.Screen name="DetailCookies" component={DetailCookies}/>
            <Stack.Screen name="DetailPopcorn" component={DetailPopcorn}/>
            <Stack.Screen name="DetailPotato" component={DetailPotato}/>
            <Stack.Screen name="DetailSalad" component={DetailSalad}/>
            <Stack.Screen name="DetailBurrito" component={DetailBurrito}/>
            <Stack.Screen name="Burger" component={Burger}/>
            <Stack.Screen name="Milktea" component={Milktea}/>
            <Stack.Screen name="Pizza" component={Pizza}/>
            <Stack.Screen name="Donut" component={Donut}/>
            <Stack.Screen name="About" component={About}/>
            <Stack.Screen name="Home1" component={Home1}/>
            <Stack.Screen name="Members" component={Members}/>
            <Stack.Screen name="Lanz" component={Lanz}/>
            <Stack.Screen name="Charmie" component={Charmie}/>
            <Stack.Screen name="Jean" component={Jean}/>
            <Stack.Screen name="Sophia" component={Sophia}/>
            <Stack.Screen name="Hannah" component={Hannah}/>
            <Stack.Screen name="MilkteaDetail1" component={MilkteaDetail1}/>
            <Stack.Screen name="MilkteaDetail2" component={MilkteaDetail2}/>
            <Stack.Screen name="MilkteaDetail3" component={MilkteaDetail3}/>
            <Stack.Screen name="MilkteaDetail4" component={MilkteaDetail4}/>
            <Stack.Screen name="MilkteaDetail5" component={MilkteaDetail5}/>
            <Stack.Screen name="MilkteaDetail6" component={MilkteaDetail6}/>
            <Stack.Screen name="BurgerDetail1" component={BurgerDetail1}/>
            <Stack.Screen name="BurgerDetail2" component={BurgerDetail2}/>
            <Stack.Screen name="BurgerDetail3" component={BurgerDetail3}/>
            <Stack.Screen name="BurgerDetail4" component={BurgerDetail4}/>
            <Stack.Screen name="BurgerDetail5" component={BurgerDetail5}/>
            <Stack.Screen name="BurgerDetail6" component={BurgerDetail6}/>
            <Stack.Screen name="DonutDetail1" component={DonutDetail1}/>
            <Stack.Screen name="DonutDetail2" component={DonutDetail2}/>
            <Stack.Screen name="DonutDetail3" component={DonutDetail3}/>
            <Stack.Screen name="DonutDetail4" component={DonutDetail4}/>
            <Stack.Screen name="DonutDetail5" component={DonutDetail5}/>
            <Stack.Screen name="DonutDetail6" component={DonutDetail6}/>
            <Stack.Screen name="PizzaDetail1" component={PizzaDetail1}/>
            <Stack.Screen name="PizzaDetail2" component={PizzaDetail2}/>
            <Stack.Screen name="PizzaDetail3" component={PizzaDetail3}/>
            <Stack.Screen name="PizzaDetail4" component={PizzaDetail4}/>
            <Stack.Screen name="PizzaDetail5" component={PizzaDetail5}/>
            <Stack.Screen name="PizzaDetail6" component={PizzaDetail6}/>

            

        </Stack.Navigator>
    )
}
export default HomeStackNavigator;