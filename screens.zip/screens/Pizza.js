import React from 'react'
import {View,Image,Picker, TouchableOpacity, Text} from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import Icon from "@expo/vector-icons/Entypo"
import Product from '../components/Product'
import ProductMilktea from '../components/ProductMilktea'
import ProductPizza from '../components/ProductPizza'
import ProductBurger from '../components/ProductBurger'
import ProductDonut from '../components/ProductDonut'





export default class Home extends React.Component{
    state={
        city:"Quezon City"
    }
    render(){
        return(
           <ScrollView style={{backgroundColor:"#FFF"}}>
               <View style={{
                   flexDirection:"row",
                   alignItems:"center",
                   marginTop:40,
                   marginHorizontal:20
               }}>

                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Home1')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:30,
                      marginTop:this.props.marginTop,
                      marginRight:0
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:0,
                       paddingHorizontal:5
                   }}/>
                       
                       <Image
                        source={require('../images/1.png')}
                        style={{height:40,width:40}}
                       />


       
                  
                   </TouchableOpacity>
                   <View style={{
                       width:"80%",
                       alignItems:"center"
                   }}>
                       <Picker
                        selectedValue={this.state.city}
                        style={{height:50,width:160}}
                        onValueChange={(itemValue,itemIndex)=>
                            this.setState({city:itemValue})
                        }
                       >
                           <Picker.Item
                            label="Quezon City"
                            value="Quezon City"
                            style={{fontWeight:"bold"}}
                           />
                            <Picker.Item
                            label="Manila"
                            value="Manila"
                            style={{fontWeight:"bold"}}
                           />
                            <Picker.Item
                            label="Caloocan City"
                            value="Caloocan City"
                            style={{fontWeight:"bold"}}
                           />
                           <Picker.Item
                            label="Marikina City"
                            value="Marikina City"
                            style={{fontWeight:"bold"}}
                           />
                             <Picker.Item
                            label="Valuenzuela City"
                            value="Valuenzuela City"
                            style={{fontWeight:"bold"}}
                           />
                       </Picker>
                   </View>
                   <View style={{width:"10%"}}>
                        <Icon name="magnifying-glass" size={30}/>
                   </View>
               </View>
               
               
               <View style={{
                   paddingHorizontal:20,
                   marginTop:50
               }}>
                   <Text style={{
                       fontSize:30,
                       fontWeight:"bold"
                   }}>Food that</Text>
                   <Text style={{
                       fontSize:30,
                       fontWeight:"bold"
                   }}>meets your needs</Text>
               </View>


               <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={{marginTop:40}}
               >
                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Burger')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:25,
                      marginTop:this.props.marginTop,
                      marginRight:10
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:5,
                       paddingHorizontal:15
                   }}>
                       <Image
                        source={require('../images/5.png')}
                        style={{height:40,width:40}}
                       />
                       <Text style={{
                           fontWeight:"bold",
                           fontSize:18,
                           paddingLeft:10
                       }}>
                           Burgers
                       </Text>
                   </View>
                   </TouchableOpacity>
                   
                   <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Milktea')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:25,
                      marginTop:this.props.marginTop,
                      marginRight:10
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:5,
                       paddingHorizontal:15
                   }}>
                       <Image
                        source={require('../images/Milktea20.png')}
                        style={{height:40,width:40}}
                       />
                       <Text style={{ 
                           fontWeight:"bold",
                           fontSize:18,
                           paddingLeft:10
                       }}>


                           Milktea
                       </Text>
                   </View>
                   </TouchableOpacity>


                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Donut')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:25,
                      marginTop:this.props.marginTop,
                      marginRight:10
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:5,
                       paddingHorizontal:15

                   }}>
                       <Image
                        source={require('../images/donut.png')}
                        style={{height:40,width:40}}

                      
                       />
                       <Text style={{
                           fontWeight:"bold",
                           fontSize:18,
                           paddingLeft:10

                       }}>

                           Donut
                       </Text>
                   </View>
                   </TouchableOpacity>

                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Pizza')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:25,
                      marginTop:this.props.marginTop,
                      marginRight:10
                     
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:5,
                       paddingHorizontal:15,

                       
                   }}>
                       <Image
                        source={require('../images/6.png')}
                        style={{height:40,width:40}}

                       />

                        
                       <Text style={{
                           fontWeight:"bold",
                           fontSize:18,
                           paddingLeft:10
                       }}>

                           Pizza
                       </Text>
                   </View>
                   </TouchableOpacity>


            </ScrollView>
                   <View style={{
                       alignItems:"center",
                       marginHorizontal:25,
                       flexDirection:"row",
                       marginTop:35
                   }}>
                       <View style={{
                           width:"50%"
                       }}>
                           <Text style={{
                               fontSize:25,
                               fontWeight:"bold"
                           }}>New Products</Text>
                       </View>
                       <View style={{
                           width:"50%",
                           alignItems:"flex-end"
                       }}>
                           <Icon
                            name="dots-three-horizontal"
                            size={30}
                            color="#848385"
                           />
                       </View>
                   </View>
                  
                  
                   <View style={{
                       flexDirection:"row",
                       marginHorizontal:30,
                       marginTop:45,
                   }}>
                       <Product
                            image={require("../images/pizza1.png")}
                            title="La Brocks"
                            price="₱150.00"
                            onPress={() => this.props.navigation.navigate('PizzaDetail1')}
                       />
                       <Product
                            image={require("../images/pizza2.png")}
                            title="La Tomato"
                            price="₱150.00"
                            marginTop={0}
                            onPress={() => this.props.navigation.navigate('PizzaDetail2')}
                       />
                   </View>

                   <View style={{
                       flexDirection:"row",
                       marginHorizontal:30,
                       marginTop:30,
                   }}>
                       <Product
                            image={require("../images/pizza3.png")}
                            title="La Viennese"
                            price="₱150.00"
                            onPress={() => this.props.navigation.navigate('PizzaDetail3')}
                       />
                       <Product
                            image={require("../images/pizza4.png")}
                            title="La Capricciosa"
                            price="₱150.00"
                            marginTop={0}
                            onPress={() => this.props.navigation.navigate('PizzaDetail4')}
                       />
                   </View>
                   <View style={{
                       flexDirection:"row",
                       marginHorizontal:30,
                       marginTop:30,
                   }}>
                    <Product
                            image={require("../images/pizza5.png")}
                            title="La romana"
                            price="₱150.00"
                            onPress={() => this.props.navigation.navigate('PizzaDetail5')}
                       />
                       <Product
                            image={require("../images/pizza6.png")}
                            title="La Calzon"
                            price="₱150.00"
                            marginTop={0}
                            onPress={() => this.props.navigation.navigate('PizzaDetail6')}
                       />
                   </View>
                   
           </ScrollView>
        )
    }
}