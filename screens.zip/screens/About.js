import React from 'react'
import {View,Text, Image} from 'react-native'
import {
    ScrollView,
    TouchableOpacity} 
    from 'react-native-gesture-handler'
import Icon from '@expo/vector-icons/Entypo'


export default class Detail extends React.Component{
    state={
        quantity:1
    }

    addQuantity = (quantity) => {
        this.setState({quantity: this.state.quantity + 1});
    }
    subtractQuantity = (quantity) => {
      if (this.state.quantity > 0) {
        this.setState({quantity: this.state.quantity - 1});
      }
       
    }

    render(){
        return(
            <View style={{backgroundColor:"#FFF"}}>
               <ScrollView>
                   <View style={{
                       flexDirection:"row",
                       alignItems:"center",
                       marginTop:40,
                       marginHorizontal:20
                   }}>
                       <View style={{width:"10%"}}>
                            <TouchableOpacity
                                onPress={()=>this.props.navigation.goBack()}
                            >
                                <Image
                                    source={require('../images/2.png')}
                                />
                            </TouchableOpacity>
                       </View>
                       <View style={{width:"80%",alignItems:"center"}}>
                            <View style={{
                                flexDirection:"row",
                                alignItems:"center",
                                alignSelf:"center"
                            }}>
                                <Image
                                    source={require('../images/3.png')}
                                    style={{height:25,width:20}}
                                />
                                <Text style={{
                                    paddingHorizontal:10,
                                    fontWeight:"bold",
                                    fontSize:16
                                }}>Profile</Text>
                            </View>
                       </View>
                       <View style={{width:"10%"}}>
                                <Icon
                                    name="heart"
                                    color="#f9dd7a"
                                    size={30}
                                />
                       </View>
                   </View>
                   <Image
                        source={require('../images/logo.png')}
                        style={{
                            height:425,
                            width:350,
                            alignSelf:"center"
                        }}
                   />
                  

                   <View style={{
                       flexDirection:"row",
                       alignItems:"center",
                       marginHorizontal:20,
                       marginTop:0
                   }}>
                       <View>
                           <Text style={{
                               fontWeight:"bold",
                               fontSize:50,
                               marginLeft:65
                              
                           }}>ABOUT US </Text>
                           <Text style={{
                               fontWeight:"bold",
                               fontSize:35,
                               color:"#000000",
                               marginLeft:30
                           }}>
                               Milktea and snacks
                           </Text>
                       </View>
                      <Text style={{
                          fontWeight:"bold",
                          fontSize:28,
                          marginLeft:135
                      }}></Text>
                   </View>
                  
                 
                   <Text style={{
                       color:"#a52a2a",
                       fontWeight:"bold",
                       fontSize:20,
                       marginTop:20,
                       marginHorizontal:20,
                       textAlign:"justify"
                   }}>
                      Milktea and snacks Company is a 100% Philippines  based company established in 2000. Over the years we have been focusing on doing only one thing: 
                      made the best quality and refreshing snacks and Milktea for consumers every day.
                   </Text>
               </ScrollView>
               </View>
              
        )
    }
}