import React from 'react'
import {View,Image,Picker, TouchableOpacity, Text} from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import Icon from "@expo/vector-icons/Entypo"
import Product from '../components/Product'
import ProductMilktea from '../components/ProductMilktea'
import ProductPizza from '../components/ProductPizza'
import ProductBurger from '../components/ProductBurger'
import ProductDonut from '../components/ProductDonut'




export default class Home extends React.Component{
    state={
        city:"Quezon City"
    }
    render(){
        return(
           <ScrollView style={{backgroundColor:"#FFF"}}>
               <View style={{
                   flexDirection:"row",
                   alignItems:"center",
                   marginTop:40,
                   marginHorizontal:20
               }}>

                   <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Home1')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:30,
                      marginTop:this.props.marginTop,
                      marginRight:0
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"row",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:15,
                       paddingVertical:0,
                       paddingHorizontal:5
                   }}/>
                       
                       <Image
                        source={require('../images/1.png')}
                        style={{height:40,width:40}}
                       />


       
                  
                   </TouchableOpacity>
                  
                   <View style={{
                       width:"80%",
                       alignItems:"center"
                   }}>
                       <Picker
                        selectedValue={this.state.city}
                        style={{height:50,width:160}}
                        onValueChange={(itemValue,itemIndex)=>
                            this.setState({city:itemValue})
                        }
                       >
                           <Picker.Item
                            label="Quezon City"
                            value="Quezon City"
                            style={{fontWeight:"bold"}}
                           />
                            <Picker.Item
                            label="Manila"
                            value="Manila"
                            style={{fontWeight:"bold"}}
                           />
                            <Picker.Item
                            label="Caloocan City"
                            value="Caloocan City"
                            style={{fontWeight:"bold"}}
                           />
                           <Picker.Item
                            label="Marikina City"
                            value="Marikina City"
                            style={{fontWeight:"bold"}}
                           />
                             <Picker.Item
                            label="Valuenzuela City"
                            value="Valuenzuela City"
                            style={{fontWeight:"bold"}}
                           />
                       </Picker>
                   </View>
                   <View style={{width:"10%"}}>
                        <Icon name="magnifying-glass" size={30}/>
                   </View>
               </View>
               
               <ScrollView
                vertical
                showsHorizontalScrollIndicator={false}
                style={{marginTop:40}}
               >
                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Home')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:15,
                      marginTop:this.props.marginTop,
                      marginRight:15,
                      marginLeft:15,
                      marginBottom:30

            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"column",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:20,
                       paddingVertical:10,
                       paddingHorizontal:20
                   }}>
                       <Image
                        source={require('../images/product.png')}
                        style={{height:60,width:70}}
                       />
                       <Text style={{
                           fontWeight:"bold",
                           fontSize:25,
                           paddingLeft:5
                       }}>
                           PRODUCTS
                       </Text>
                   </View>
                   </TouchableOpacity>
                   
                   <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('About')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:15,
                      marginTop:this.props.marginTop,
                      marginRight:15,
                      marginLeft:15,
                      marginBottom:30
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"column",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:20,
                       paddingVertical:10,
                       paddingHorizontal:20
                   }}>
                       <Image
                        source={require('../images/about.png')}
                        style={{height:60,width:60}}
                       />
                       <Text style={{ 
                           fontWeight:"bold",
                           fontSize:25,
                           paddingLeft:5
                       }}>

                           ABOUT US
                       </Text>
                   </View>
                   </TouchableOpacity>


                  <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('Members')}
                      style={{
                      backgroundColor:"#f5f5fa",
                      borderRadius:15,
                      marginTop:this.props.marginTop,
                      marginRight:15,
                      marginLeft:15
            }}>

                   <View style={{
                       alignItems:"center",
                       flexDirection:"column",
                       backgroundColor:"#f5f5fa",
                       marginHorizontal:20,
                       paddingVertical:10,
                       paddingHorizontal:20

                   }}>
                       <Image
                        source={require('../images/members.png')}
                        style={{height:60,width:60}}

                      
                       />
                       <Text style={{
                           fontWeight:"bold",
                           fontSize:25,
                           paddingLeft:5

                       }}>

                          MEMBERS
                       </Text>
                   </View>
                   </TouchableOpacity>

                   

                  

            </ScrollView>
                   
                  
                   
           </ScrollView>
        )
    }
}