import React from 'react'
import {View,Text, Image} from 'react-native'
import {
    ScrollView,
    TouchableOpacity} 
    from 'react-native-gesture-handler'
import Icon from '@expo/vector-icons/Entypo'


export default class Detail extends React.Component{
    state={
        quantity:1
    }

    addQuantity = (quantity) => {
        this.setState({quantity: this.state.quantity + 1});
    }
    subtractQuantity = (quantity) => {
      if (this.state.quantity > 0) {
        this.setState({quantity: this.state.quantity - 1});
      }
       
    }

    render(){
        return(
            <View style={{backgroundColor:"#FFF"}}>
               <ScrollView>
                   <View style={{
                       flexDirection:"row",
                       alignItems:"center",
                       marginTop:40,
                       marginHorizontal:20
                   }}>
                       <View style={{width:"10%"}}>
                            <TouchableOpacity
                                onPress={()=>this.props.navigation.goBack()}
                            >
                                <Image
                                    source={require('../images/2.png')}
                                />
                            </TouchableOpacity>
                       </View>
                       <View style={{width:"80%",alignItems:"center"}}>
                            <View style={{
                                flexDirection:"row",
                                alignItems:"center",
                                alignSelf:"center"
                            }}>
                                <Image
                                    source={require('../images/3.png')}
                                    style={{height:25,width:20}}
                                />
                                <Text style={{
                                    paddingHorizontal:10,
                                    fontWeight:"bold",
                                    fontSize:16
                                }}>Profile</Text>
                            </View>
                       </View>
                       <View style={{width:"10%"}}>
                                <Icon
                                    name="heart"
                                    color="#f9dd7a"
                                    size={30}
                                />
                       </View>
                   </View>
                   <Image
                        source={require('../images/Sophia.jpg')}
                        style={{
                            height:425,
                            width:350,
                            alignSelf:"center"
                        }}
                   />
                  

                   <View style={{
                       flexDirection:"row",
                       alignItems:"center",
                       marginHorizontal:20,
                       marginTop:0
                   }}>
                       <View>
                           <Text style={{
                               fontWeight:"bold",
                               fontSize:30,
                               marginLeft:40
                              
                           }}>Sophia Jean Lanticse</Text>
                           
                       </View>
                      <Text style={{
                          fontWeight:"bold",
                          fontSize:28,
                          marginLeft:135
                      }}></Text>
                   </View>
                  
                 
                   <Text style={{
                       color:"#a52a2a",
                       fontWeight:"bold",
                       fontSize:20,
                       marginTop:20,
                       marginHorizontal:20,
                       textAlign:"justify"
                   }}>
                       A 3rd year students taking up BSIT in TIP, about her is someone who you can trust, If she says she will do something, she will do it. She’s the friend who makes us happy and who we can have fun with. 
                      She’s the friend who puts a smile on our faces and helps us kill the stress from our working day.
                   </Text>
               </ScrollView>
               </View>
              
        )
    }
}